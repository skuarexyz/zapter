import zapterpy, random

bot_name = "TextGenBot"

class TextGenBot(zapterpy.ZapterUser):
    def on_name_accepted(self, data):
        super().on_name_accepted(data)
        self.sendMessage("what's up motherfuckers")
    
    def on_message(self, data):
        if data['username'] != bot_name:
            if data['message'].startswith("!generate"):
                words = data['message'].split(" ")
                args = words[1:]
                if len(args) == 0:
                    self.sendMessage("!generate <number of words>")
                else:
                    # generate a message
                    last_word_ended_a_sentence = True
                    gen_words = []
                    for i in range(int(args[0])):
                        print(gen_words)
                        if last_word_ended_a_sentence:
                            # take a random sentence starting word
                            word = random.choice(list(self.sentenceStartingWords.keys()))
                            gen_words.append(word)
                        else:
                            # take one of the 3 most common words following the previous word
                            frequencies = self.frequencyTable[gen_words[-1]]
                            # get the three most common words
                            common_words = list(frequencies.keys())[:min(len(frequencies.keys()), 3)]
                            # get a random word from the three most common words
                            word = random.choice(common_words)
                            gen_words.append(word)
                        last_word_ended_a_sentence = word.endswith(".") or word.endswith("!") or word.endswith("?")
                    self.sendMessage(" ".join(gen_words))
                            

try:
    bot = TextGenBot()
    bot.connect("https://535e-2a01-cb11-6bc-a900-f0e1-f274-2c15-2cd.ngrok.io/", bot_name)
except KeyboardInterrupt:
    print("Exiting")
    exit(0)
except Exception as e:
    print(e)
    exit(1)